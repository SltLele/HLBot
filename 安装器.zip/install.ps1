﻿param([string]$Language = "")

# ============================================================
# ASCII BOOT - PowerShell version & encoding check
#   中文在上，英文在下（若中文乱码，仍可读英文）
# ============================================================
$ErrorActionPreference = 'Continue'
$psv = $PSVersionTable.PSVersion
$psMajor = $psv.Major

# ============================================================
# 应用信息
# ============================================================
$AppName    = "HLBot Installer"
$AppVersion = "0.3.1"

# ============================================================
# 通用退出函数：双击启动时等用户按键，命令行启动时直接退出
# ============================================================
function Exit-Safe {
    param([int]$Code = 0, [switch]$NoWait)
    if (-not $NoWait -and $env:HLBOT_NOEXIT -eq "1") {
        Write-Host ""
        Write-Host "按任意键关闭窗口... / Press any key to close..."
        try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Start-Sleep 5 }
    }
    exit $Code
}

function Exit-NoUpload {
    param([string]$ExitMessage = "用户主动退出")
    Write-Host ""
    Write-Host $ExitMessage
    Exit-Safe 0
}

# ============================================================
# 处理命令行参数：支持直接拖入本地 zip 安装包
# ============================================================
$script:LocalZipPath = ""
if ($Language -match '\.zip$') {
    $script:LocalZipPath = $Language
    $Language = ""
}
if ($script:LocalZipPath -and -not (Test-Path -LiteralPath $script:LocalZipPath)) {
    Write-Host ""
    Write-Host "[警告] 命令行传入的 zip 路径无效: $($script:LocalZipPath)" -ForegroundColor Yellow
    Write-Host "[WARN] Invalid zip path from arguments: $($script:LocalZipPath)" -ForegroundColor Yellow
    $script:LocalZipPath = ""
}

if ($script:LocalZipPath) {
    $script:TitleSuffix = " [本地安装包 / Local Package]"
} else {
    $script:TitleSuffix = ""
}

# ============================================================
# 自动切换到 PowerShell 7
#   切换前先验证 pwsh 可用性（避免 MSIX 许可证损坏的场景）
# ============================================================
if ($psMajor -lt 7 -and $env:HLBOT_RELAUNCHED -ne "1") {
    $pwshCandidates = @(
        "C:\Program Files\PowerShell\7\pwsh.exe",
        "C:\Program Files\PowerShell\7-preview\pwsh.exe",
        (Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\pwsh.exe")
    )
    $pwshPath = $null
    foreach ($c in $pwshCandidates) {
        if (Test-Path -LiteralPath $c) { $pwshPath = $c; break }
    }
    if (-not $pwshPath) {
        $cmd = Get-Command pwsh -ErrorAction SilentlyContinue
        if ($cmd) { $pwshPath = $cmd.Source }
    }

    if ($pwshPath) {
        $pwshOk = $false
        try {
            $tp = Start-Process -FilePath $pwshPath -ArgumentList @("-NoLogo", "-NoProfile", "-Command", "exit 0") -PassThru -WindowStyle Hidden
            if ($tp.WaitForExit(5000)) {
                if ($tp.ExitCode -eq 0) { $pwshOk = $true }
            } else {
                try { $tp.Kill() } catch {}
            }
        } catch {}

        if (-not $pwshOk) {
            Write-Host ""
            Write-Host "================================================================" -ForegroundColor Yellow
            Write-Host " [提示] 检测到 pwsh.exe 存在，但无法正常运行。" -ForegroundColor Yellow
            Write-Host "        可能安装不完整或许可证损坏。" -ForegroundColor Yellow
            Write-Host "        跳过自动切换，使用当前 PowerShell 继续。" -ForegroundColor Yellow
            Write-Host " [INFO] pwsh.exe exists but cannot run properly." -ForegroundColor Yellow
            Write-Host "        Skipping auto-switch, using current PowerShell." -ForegroundColor Yellow
            Write-Host "================================================================" -ForegroundColor Yellow
            Write-Host ""
            $pwshPath = $null
            Start-Sleep -Seconds 2
        }
    }

    if ($pwshPath) {
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host " [启动] 检测到可用的 PowerShell 7，正在自动切换到新版运行..." -ForegroundColor Cyan
        Write-Host "        $pwshPath" -ForegroundColor DarkGray
        Write-Host " [Boot] Working PowerShell 7 detected, switching..." -ForegroundColor Cyan
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host ""
        Start-Sleep -Seconds 2

        $bootSelf = $MyInvocation.MyCommand.Path
        if ([string]::IsNullOrEmpty($bootSelf)) { $bootSelf = $PSCommandPath }
        $bootDir = $PSScriptRoot
        if ([string]::IsNullOrEmpty($bootDir)) {
            try { $bootDir = Split-Path -Parent $bootSelf } catch {}
        }
        if ([string]::IsNullOrEmpty($bootDir)) { $bootDir = (Get-Location).Path }

        if ($bootSelf -and (Test-Path -LiteralPath $bootSelf)) {
            $env:HLBOT_RELAUNCHED = "1"
            $argStr = "-NoLogo -NoExit -ExecutionPolicy Bypass -File `"$bootSelf`""
            if ($script:LocalZipPath) {
                $esc = $script:LocalZipPath -replace '"', '\"'
                $argStr += " `"$esc`""
            }
            try {
                Start-Process -FilePath $pwshPath -ArgumentList $argStr -WorkingDirectory $bootDir
                Exit-Safe 0 -NoWait
            } catch {
                Write-Host "[警告] 切换到 PowerShell 7 失败，继续使用当前版本。" -ForegroundColor Yellow
                Write-Host "[WARN] Failed to switch to PowerShell 7, continuing." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    }
}

Write-Host ""
if ($psMajor -lt 7) {
    if ($psMajor -lt 5 -or ($psMajor -eq 5 -and $psv.Minor -lt 1)) {
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host " [错误] PowerShell 版本过旧: $psv" -ForegroundColor Red
        Write-Host "        本安装程序需要 PowerShell 5.1 或更高版本。" -ForegroundColor Red
        Write-Host "        请先升级 PowerShell，否则安装可能失败或报错。" -ForegroundColor Red
        Write-Host "        下载地址: https://aka.ms/pswindows" -ForegroundColor Red
        Write-Host " [ERROR] PowerShell version too old: $psv" -ForegroundColor Red
        Write-Host "         HLBot installer requires PowerShell 5.1 or newer." -ForegroundColor Red
        Write-Host "         Please upgrade before running this installer." -ForegroundColor Red
        Write-Host "         Download: https://aka.ms/pswindows" -ForegroundColor Red
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "按任意键退出... / Press any key to exit..."
        try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Start-Sleep 5 }
        Exit-Safe 1
    }

    Write-Host "================================================================" -ForegroundColor Yellow
    Write-Host " [警告] 当前 PowerShell 版本: $psv" -ForegroundColor Yellow
    Write-Host "        HLBot 在 PowerShell 7.x 上运行效果最佳。" -ForegroundColor Yellow
    Write-Host "        旧版可能导致安装失败或中文乱码。" -ForegroundColor Yellow
    Write-Host " [WARN] Current PowerShell version: $psv" -ForegroundColor Yellow
    Write-Host "        HLBot works best with PowerShell 7.x." -ForegroundColor Yellow
    Write-Host "        Old version may cause install failures or garbled text." -ForegroundColor Yellow
    Write-Host "================================================================" -ForegroundColor Yellow
    Write-Host ""

    $ansUpdate = Read-Host "是否升级到 PowerShell 7？(y/n) / Upgrade to PowerShell 7? (y/n)"
    if ($ansUpdate -match '^[Yy]') {
        $upgradeFinished = $false
        while (-not $upgradeFinished) {
            Write-Host ""
            Write-Host "请选择升级方式 / Choose upgrade method:" -ForegroundColor Cyan
            Write-Host "  1. 自动从 GitHub 下载并安装（推荐）" -ForegroundColor Cyan
            Write-Host "     Auto download from GitHub (recommended)" -ForegroundColor DarkGray
            Write-Host "  2. 打开浏览器手动下载" -ForegroundColor Cyan
            Write-Host "     Open browser to download manually" -ForegroundColor DarkGray
            Write-Host "  3. 手动输入下载网址" -ForegroundColor Cyan
            Write-Host "     Enter download URL manually" -ForegroundColor DarkGray
            Write-Host "  0. 取消升级" -ForegroundColor Cyan
            Write-Host "     Cancel upgrade" -ForegroundColor DarkGray
            $method = (Read-Host "请选择 (0-3) / Choose (0-3)").Trim()

            if ($method -eq "0") {
                Write-Host "已取消升级。/ Upgrade cancelled." -ForegroundColor Yellow
                $upgradeFinished = $true
                break
            }

            if ($method -eq "2") {
                Write-Host ""
                Write-Host "正在打开浏览器..." -ForegroundColor Cyan
                Write-Host "Opening browser..." -ForegroundColor Cyan
                try { Start-Process "https://github.com/PowerShell/PowerShell/releases/latest" } catch {}
                Write-Host ""
                Write-Host "请在浏览器下载 PowerShell-7.x.x-win-x64.msi 并双击安装。" -ForegroundColor Yellow
                Write-Host "Please download PowerShell-7.x.x-win-x64.msi and install it." -ForegroundColor Yellow
                Write-Host "安装完成后，请关闭本窗口，重新运行 install.bat。" -ForegroundColor Yellow
                Write-Host "After install, close this window and rerun install.bat." -ForegroundColor Yellow
                Write-Host ""
                Write-Host "按任意键退出... / Press any key to exit..."
                try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
                Exit-Safe 0
            }

            $msiUrl = $null
            $asset = $null

            if ($method -eq "1") {
                Write-Host ""
                Write-Host "正在从 GitHub 获取最新版本信息..." -ForegroundColor Cyan
                Write-Host "Fetching latest release from GitHub..." -ForegroundColor Cyan

                try {
                    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
                } catch {}

                try {
                    $headers = @{ "User-Agent" = "HLBot-Installer" }
                    $release = Invoke-RestMethod -Uri "https://api.github.com/repos/PowerShell/PowerShell/releases/latest" -Headers $headers -TimeoutSec 20
                    $asset = $release.assets | Where-Object {
                        $_.name -match '^PowerShell-.*-win-x64\.msi$' -and $_.name -notmatch 'preview|fxdependent'
                    } | Select-Object -First 1
                    if ($asset) {
                        $msiUrl = $asset.browser_download_url
                        Write-Host "  版本 / Version : $($release.tag_name)" -ForegroundColor Green
                        Write-Host "  文件 / File    : $($asset.name)" -ForegroundColor Green
                        Write-Host "  大小 / Size    : $([math]::Round($asset.size / 1MB, 1)) MB" -ForegroundColor Green
                    } else {
                        Write-Host "[错误] 最新 Release 中未找到 x64 MSI 包。" -ForegroundColor Red
                        Write-Host "[ERROR] x64 MSI asset not found in latest release." -ForegroundColor Red
                    }
                } catch {
                    Write-Host "[错误] GitHub API 请求失败: $_" -ForegroundColor Red
                    Write-Host "[ERROR] GitHub API request failed: $_" -ForegroundColor Red
                    Write-Host "请改用手动方式。" -ForegroundColor Yellow
                    Write-Host "Please choose manual method." -ForegroundColor Yellow
                }
            }
            elseif ($method -eq "3") {
                Write-Host ""
                $inputUrl = (Read-Host "请输入 PowerShell 7 MSI 下载网址 / Enter MSI download URL").Trim()
                if ($inputUrl -match '^https?://' -and $inputUrl -match '\.msi($|\?)') {
                    $msiUrl = $inputUrl
                } else {
                    Write-Host "[错误] 网址无效，须以 http(s):// 开头且以 .msi 结尾。" -ForegroundColor Red
                    Write-Host "[ERROR] Invalid URL, must start with http(s):// and end with .msi." -ForegroundColor Red
                }
            }
            else {
                Write-Host "[错误] 无效输入。/ Invalid input." -ForegroundColor Red
                Start-Sleep -Seconds 1
                continue
            }

            if (-not $msiUrl) {
                Start-Sleep -Seconds 1
                continue
            }

            $sizeHint = ""
            if ($asset -and $asset.size -gt 0) {
                $mb = [math]::Round($asset.size / 1MB, 1)
                $sizeHint = "，约 $mb MB / ~ $mb MB"
            }
            Write-Host ""
            $confirm = (Read-Host "将从 github.com 下载 PowerShell 7$sizeHint。继续？(y/n) / Download? (y/n)").Trim()
            if ($confirm -notmatch '^[Yy]') {
                Write-Host "已取消下载。/ Download cancelled." -ForegroundColor Yellow
                continue
            }

            try {
                $uri = New-Object System.Uri($msiUrl)
                $fileName = [System.IO.Path]::GetFileName($uri.AbsolutePath)
                if ([string]::IsNullOrEmpty($fileName)) { $fileName = "PowerShell-7-win-x64.msi" }
            } catch {
                $fileName = "PowerShell-7-win-x64.msi"
            }
            $msiLocalPath = Join-Path $env:TEMP $fileName

            Write-Host ""
            Write-Host "正在下载: $msiUrl" -ForegroundColor Cyan
            Write-Host "Downloading: $msiUrl" -ForegroundColor Cyan

            $downloadOk = $false
            try {
                $req = [System.Net.HttpWebRequest]::Create($msiUrl)
                $req.Method = "GET"
                $req.UserAgent = "HLBot-Installer"
                $req.Timeout = 60000
                $req.ReadWriteTimeout = 300000
                $req.AllowAutoRedirect = $true
                $resp = $req.GetResponse()
                $totalLen = $resp.ContentLength
                $stream = $resp.GetResponseStream()
                $fs = New-Object System.IO.FileStream($msiLocalPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write)
                $buf = New-Object byte[] 81920
                $read = [long]0
                $last = [DateTime]::Now
                try {
                    while ($true) {
                        $n = $stream.Read($buf, 0, $buf.Length)
                        if ($n -le 0) { break }
                        $fs.Write($buf, 0, $n)
                        $read += $n
                        if (([DateTime]::Now - $last).TotalMilliseconds -gt 500) {
                            if ($totalLen -gt 0) {
                                $pct = [math]::Round($read * 100.0 / $totalLen, 1)
                                Write-Host -NoNewline "`r  下载中: $pct% ($([math]::Round($read/1MB,1)) / $([math]::Round($totalLen/1MB,1)) MB)"
                            } else {
                                Write-Host -NoNewline "`r  已下载: $([math]::Round($read/1MB,1)) MB"
                            }
                            $last = [DateTime]::Now
                        }
                    }
                } finally {
                    $fs.Close()
                    $stream.Close()
                    $resp.Close()
                }
                Write-Host ""
                $downloadOk = $true
            } catch {
                Write-Host ""
                Write-Host "[错误] 下载失败: $_" -ForegroundColor Red
                Write-Host "[ERROR] Download failed: $_" -ForegroundColor Red
            }

            if (-not $downloadOk) {
                Write-Host "请重试或改用手动方式。" -ForegroundColor Yellow
                Write-Host "Please retry or use manual method." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
                continue
            }

            Write-Host "已保存到: $msiLocalPath" -ForegroundColor Green
            Write-Host "Saved to: $msiLocalPath" -ForegroundColor Green
            Write-Host ""
            Write-Host "正在启动安装程序（可能弹出 UAC，请点击 [是] 允许）..." -ForegroundColor Cyan
            Write-Host "Launching installer (UAC may pop up, click [Yes] to allow)..." -ForegroundColor Cyan

            try {
                Start-Process -FilePath "msiexec.exe" -ArgumentList @("/i", "`"$msiLocalPath`"", "/qb", "/norestart") -Verb RunAs -Wait
            } catch {
                Write-Host "[错误] 启动安装程序失败: $_" -ForegroundColor Red
                Write-Host "[ERROR] Failed to launch installer: $_" -ForegroundColor Red
                Write-Host "请手动双击运行: $msiLocalPath" -ForegroundColor Yellow
                Write-Host "Please run manually: $msiLocalPath" -ForegroundColor Yellow
                Write-Host ""
                Write-Host "按任意键退出... / Press any key to exit..."
                try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
                Exit-Safe 1
            }

            Write-Host ""
            Write-Host "安装命令已返回，正在查找 pwsh.exe..." -ForegroundColor Cyan
            Write-Host "Installer finished, searching for pwsh.exe..." -ForegroundColor Cyan

            $pwshFound = $null
            for ($i = 0; $i -lt 15; $i++) {
                $candidates = @(
                    "C:\Program Files\PowerShell\7\pwsh.exe",
                    "C:\Program Files\PowerShell\7-preview\pwsh.exe",
                    (Join-Path $env:LOCALAPPDATA "Microsoft\WindowsApps\pwsh.exe")
                )
                foreach ($c in $candidates) {
                    if (Test-Path -LiteralPath $c) { $pwshFound = $c; break }
                }
                if (-not $pwshFound) {
                    $cmd = Get-Command pwsh -ErrorAction SilentlyContinue
                    if ($cmd) { $pwshFound = $cmd.Source }
                }
                if ($pwshFound) { break }
                Start-Sleep -Seconds 2
            }

            $bootSelf2 = $MyInvocation.MyCommand.Path
            if ([string]::IsNullOrEmpty($bootSelf2)) { $bootSelf2 = $PSCommandPath }
            $bootDir2 = $PSScriptRoot
            if ([string]::IsNullOrEmpty($bootDir2)) {
                try { $bootDir2 = Split-Path -Parent $bootSelf2 } catch {}
            }
            if ([string]::IsNullOrEmpty($bootDir2)) {
                $bootDir2 = (Get-Location).Path
            }

            if ($pwshFound -and $bootSelf2 -and (Test-Path -LiteralPath $bootSelf2)) {
                Write-Host ""
                Write-Host "================================================================" -ForegroundColor Green
                Write-Host " 已找到 PowerShell 7: $pwshFound" -ForegroundColor Green
                Write-Host " 正在用 PowerShell 7 自动重新启动安装程序..." -ForegroundColor Green
                Write-Host " Found PowerShell 7: $pwshFound" -ForegroundColor Green
                Write-Host " Relaunching installer with PowerShell 7..." -ForegroundColor Green
                Write-Host "================================================================" -ForegroundColor Green
                Write-Host ""
                Start-Sleep -Seconds 2
                $env:HLBOT_RELAUNCHED = "1"
                $argStr = "-NoLogo -NoExit -ExecutionPolicy Bypass -File `"$bootSelf2`""
                if ($script:LocalZipPath) {
                    $esc = $script:LocalZipPath -replace '"', '\"'
                    $argStr += " `"$esc`""
                }
                try {
                    Start-Process -FilePath $pwshFound -ArgumentList $argStr -WorkingDirectory $bootDir2
                    Exit-Safe 0 -NoWait
                } catch {
                    Write-Host "[错误] 启动 PowerShell 7 失败: $_" -ForegroundColor Red
                    Write-Host "[ERROR] Failed to launch PowerShell 7: $_" -ForegroundColor Red
                    Write-Host "请手动打开 PowerShell 7 (pwsh)，然后运行 install.bat" -ForegroundColor Yellow
                    Write-Host "Please open PowerShell 7 (pwsh) manually, then run install.bat" -ForegroundColor Yellow
                    Write-Host ""
                    Write-Host "按任意键退出... / Press any key to exit..."
                    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
                    Exit-Safe 1
                }
            } else {
                Write-Host ""
                Write-Host "================================================================" -ForegroundColor Yellow
                Write-Host " [提示] 安装已完成，但未能自动找到 pwsh.exe。" -ForegroundColor Yellow
                Write-Host "        请手动打开 PowerShell 7 后重新运行 install.bat：" -ForegroundColor Yellow
                Write-Host "        1) 开始菜单搜索 PowerShell 7 或 pwsh" -ForegroundColor Yellow
                Write-Host "        2) Win+R 输入 pwsh 回车" -ForegroundColor Yellow
                Write-Host "        3) 在新窗口中运行 install.bat" -ForegroundColor Yellow
                Write-Host " [INFO] Install finished but pwsh.exe was not found." -ForegroundColor Yellow
                Write-Host "        Please open PowerShell 7 manually and rerun install.bat." -ForegroundColor Yellow
                Write-Host "================================================================" -ForegroundColor Yellow
                Write-Host ""
                Write-Host "按任意键退出... / Press any key to exit..."
                try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
                Exit-Safe 0
            }
        }
    }

    Write-Host ""
    $ansContinue = (Read-Host "是否仍要继续使用当前旧版本？(y/n) / Continue with current old version? (y/n)").Trim()
    if ($ansContinue -notmatch '^[Yy]') { Exit-Safe 1 }
}

# ============================================================
# 1. B2 credentials
# ============================================================
$B2_KeyId = "0052caa409f74aa0000000001"
$B2_AppKey = "K005T2xkJIzZfXp0Tks/5ukGblRF/Ok"
$B2_BucketName = "hlbot-log"

# ============================================================
# 2. Paths & logging
# ============================================================
$ScriptDir = $PSScriptRoot
if ([string]::IsNullOrEmpty($ScriptDir)) {
    try { $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path } catch {}
}
if ([string]::IsNullOrEmpty($ScriptDir)) {
    $ScriptDir = (Get-Location).Path
    Write-Host "[WARN] Cannot resolve script path, using cwd: $ScriptDir"
}
$ScriptDir = $ScriptDir.TrimEnd('\')

$LogFile        = Join-Path $ScriptDir "install.log"
$TranscriptFile = Join-Path $ScriptDir "install_transcript.log"
$AgreementFile  = Join-Path $ScriptDir ".hlbot_agreement"
$AgreementVer   = "1"
$LangFile       = Join-Path $ScriptDir ".hlbot_lang"

$script:TranscriptStopped = $false
try { Start-Transcript -Path $TranscriptFile -Append -ErrorAction SilentlyContinue | Out-Null } catch {}

# ============================================================
# 3. 工具函数（语言选择阶段就要用到）
# ============================================================
function Read-FileText {
    param([string]$Path)
    try { return [System.IO.File]::ReadAllText($Path) } catch { return $null }
}

function Write-FileText {
    param([string]$Path, [string]$Content)
    try {
        $enc = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($Path, $Content, $enc)
        return $true
    } catch { return $false }
}

# ============================================================
# 3.1 隐藏文件
# ============================================================
function Set-FileHidden {
    param([string]$Path)
    if ([string]::IsNullOrEmpty($Path)) { return }
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return }
        $item = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        if ($null -eq $item) { return }
        $attrs = $item.Attributes
        if (-not ($attrs -band [System.IO.FileAttributes]::Hidden)) {
            $item.Attributes = $attrs -bor [System.IO.FileAttributes]::Hidden
        }
    } catch {
        # FAT32/exFAT 等文件系统可能不支持，静默忽略
    }
}

# 隐藏列表：
#   - 程序生成文件（日志、记忆文件）
#   - 程序核心文件（用户通常不需要直接编辑）
# 不隐藏：
#   - launcher.bat / install.bat / install.ps1（用户双击入口）
#   - user.txt（用户自定义）
#   - 官方默认脚本.js（用户可能想修改）
#   - 用户自行添加的机器人脚本
function Hide-GeneratedFiles {
    param([string]$BaseDir)
    if ([string]::IsNullOrEmpty($BaseDir)) { return }
    $names = @(
        'install.log',
        'install_transcript.log',
        'error.log',
        '.hlbot_agreement',
        '.hlbot_lang',
        'launcher.js',
        'auth.js',
        'help.txt',
        'package.json',
        'package-lock.json'
    )
    foreach ($n in $names) {
        $p = Join-Path $BaseDir $n
        Set-FileHidden -Path $p
    }
}

# 启动时立即处理一次已有文件
Hide-GeneratedFiles -BaseDir $ScriptDir

# ============================================================
# 4. 语言选择（协议之前，选一次记住）
# ============================================================
function Get-SystemDefaultLang {
    try {
        $culture = [System.Globalization.CultureInfo]::CurrentUICulture
        $name = $culture.Name
        if ($name -like 'zh*') { return 'zh' }
        return 'en'
    } catch {
        return 'zh'
    }
}

$resolvedLang = $null

# 优先级 1：命令行
if ($Language -eq 'en' -or $Language -eq 'zh') {
    $resolvedLang = $Language
}

# 优先级 2：记忆文件
if (-not $resolvedLang -and (Test-Path -LiteralPath $LangFile)) {
    $saved = (Read-FileText $LangFile)
    if ($saved) {
        $saved = $saved.Trim()
        if ($saved -eq 'en' -or $saved -eq 'zh') {
            $resolvedLang = $saved
        }
    }
}

# 优先级 3：交互选择
if (-not $resolvedLang) {
    $defaultLang = Get-SystemDefaultLang
    $defaultHint = if ($defaultLang -eq 'zh') { "1" } else { "2" }
    while ($true) {
        Clear-Host
        Write-Host "========================================"
        Write-Host "  $AppName v$AppVersion$($script:TitleSuffix)" -ForegroundColor Cyan
        Write-Host "========================================"
        Write-Host ""
        Write-Host "  请选择你的语言 / Please select your language:" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "    1. 简体中文"
        Write-Host "    2. English"
        Write-Host ""
        Write-Host "  (下次启动将自动使用此选择 / This choice will be remembered)" -ForegroundColor DarkGray
        Write-Host ""
        $ans = (Read-Host "  请输入选项 (1/2，默认 $defaultHint)").Trim()
        if ([string]::IsNullOrEmpty($ans)) {
            $resolvedLang = $defaultLang
            break
        }
        if ($ans -eq '1') { $resolvedLang = 'zh'; break }
        if ($ans -eq '2') { $resolvedLang = 'en'; break }
        Write-Host "  无效输入，请重新选择。/ Invalid input, please retry." -ForegroundColor Yellow
        Start-Sleep -Seconds 1
    }
    try { Write-FileText -Path $LangFile -Content $resolvedLang | Out-Null } catch {}
    Set-FileHidden -Path $LangFile
}

$Lang = $resolvedLang

# ============================================================
# 5. Constants
# ============================================================
$NodeVersion      = "v24.15.0"
$NodeMinMajor     = 16
$NodeInstallerUrl = "https://nodejs.org/dist/$NodeVersion/node-$NodeVersion-x64.msi"

$LatestTxtUrls = @(
    "https://github.com/SltLele/HLBot/releases/download/%E4%B8%8B%E8%BD%BD%E9%93%BE%E6%8E%A5/Latest.txt",
    "https://tree-iad1-0004.secure.backblaze.com/api/user_b2_download_file?action=download_files&accountId=2caa409f74aa&bucketId=e29c8aaac4f0299fa7040a1a&fileIds=4_ze29c8aaac4f0299fa7040a1a_f1072ceb558a3a9a9_d20260822_m144723_c005_v0501048_t0038_u01787410043504"
)

$ProtectedPaths = @(
    'node_modules','HLBot_data','user.txt','.hlbot_agreement','.hlbot_lang',
    'install.log','install_transcript.log','error.log','backup'
)

$RequiredUpdateFiles = @('launcher.js','auth.js','官方默认脚本.js','help.txt')

# ============================================================
# 6. Helpers
# ============================================================
function Write-Log {
    param([string]$Message)
    $entry = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
    Add-Content -Path $LogFile -Value $entry -ErrorAction SilentlyContinue
    Write-Host $Message
    Set-FileHidden -Path $LogFile
}

function Wait-Key {
    Write-Host ""
    Write-Host "按任意键继续..."
    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Start-Sleep 3 }
}

function Get-PublicIP {
    try { return (Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 5).Trim() }
    catch {
        try { return (Invoke-RestMethod -Uri "https://ifconfig.me/ip" -TimeoutSec 5).Trim() }
        catch { return "无法获取IP" }
    }
}

function Test-SafeTempDir {
    param([string]$Path)
    if ([string]::IsNullOrEmpty($Path)) { return $false }
    $t = $Path.Trim().TrimEnd('\').TrimEnd('/')
    if ([string]::IsNullOrEmpty($t)) { return $false }
    if ($t -match '^[A-Za-z]:$') { return $false }
    if ($t -match '^\\\\?$') { return $false }
    if ($t.Length -lt 6) { return $false }
    $bad = @($env:SystemRoot, $env:windir, $env:ProgramFiles, ${env:ProgramFiles(x86)},
             $env:ProgramData, $env:USERPROFILE, $env:APPDATA, $env:LOCALAPPDATA)
    foreach ($b in $bad) {
        if ([string]::IsNullOrEmpty($b)) { continue }
        if ($t.ToLower() -eq $b.TrimEnd('\').ToLower()) { return $false }
    }
    return $true
}

function Stop-TranscriptOnce {
    if ($script:TranscriptStopped) { return }
    try {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
        $script:TranscriptStopped = $true
    } catch {}
}

function Get-UrlText {
    param([string]$Url, [int]$TimeoutSec = 15)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = "GET"
        $req.UserAgent = "HLBot-Installer/1.0"
        $req.Timeout = $TimeoutSec * 1000
        $req.AllowAutoRedirect = $true
        $resp = $req.GetResponse()
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $text = $sr.ReadToEnd()
        $sr.Close()
        $resp.Close()
        return $text
    } catch { return $null }
}

function Download-File {
    param([string]$Url, [string]$OutputPath, [int]$MaxRetries = 3, [int]$TimeoutSec = 60, [switch]$Quiet)
    for ($a = 1; $a -le $MaxRetries; $a++) {
        $partPath = "$OutputPath.part"
        try {
            $existing = 0
            if (Test-Path -LiteralPath $partPath) {
                try { $existing = (Get-Item -LiteralPath $partPath).Length } catch { $existing = 0 }
            }
            $req = [System.Net.HttpWebRequest]::Create($Url)
            $req.Method = "GET"
            $req.UserAgent = "HLBot-Installer/1.0"
            $req.Timeout = $TimeoutSec * 1000
            $req.ReadWriteTimeout = 300000
            $req.AllowAutoRedirect = $true
            if ($existing -gt 0) { $req.AddRange([long]$existing) }
            $resp = $req.GetResponse()
            $status = [int]$resp.StatusCode
            $len = $resp.ContentLength
            if ($existing -gt 0 -and $status -eq 200) {
                $existing = 0
                Remove-Item -LiteralPath $partPath -Force -ErrorAction SilentlyContinue
            }
            $stream = $resp.GetResponseStream()
            $mode = if ($existing -gt 0) { [System.IO.FileMode]::Append } else { [System.IO.FileMode]::Create }
            $fs = New-Object System.IO.FileStream($partPath, $mode, [System.IO.FileAccess]::Write)
            $buf = New-Object byte[] 81920
            $read = [long]$existing
            $last = [DateTime]::Now
            try {
                while ($true) {
                    $n = $stream.Read($buf, 0, $buf.Length)
                    if ($n -le 0) { break }
                    $fs.Write($buf, 0, $n)
                    $read += $n
                    if (-not $Quiet -and ([DateTime]::Now - $last).TotalMilliseconds -gt 500) {
                        $total = $len + $existing
                        if ($total -gt 0) {
                            $pct = [math]::Round($read * 100.0 / $total, 1)
                            Write-Host -NoNewline "`r  下载中: $pct% ($([math]::Round($read/1MB,2)) MB)"
                        } else {
                            Write-Host -NoNewline "`r  下载中: $([math]::Round($read/1MB,2)) MB"
                        }
                        $last = [DateTime]::Now
                    }
                }
            } finally {
                $fs.Close()
                $stream.Close()
                $resp.Close()
            }
            if (-not $Quiet) { Write-Host "" }
            if ($len -gt 0) {
                $exp = $existing + $len
                $act = (Get-Item -LiteralPath $partPath).Length
                if ($act -ne $exp) { throw "size mismatch (expect $exp, got $act)" }
            }
            if (Test-Path -LiteralPath $OutputPath) { Remove-Item -LiteralPath $OutputPath -Force -ErrorAction SilentlyContinue }
            Move-Item -LiteralPath $partPath -Destination $OutputPath -Force
            return $true
        } catch {
            if (-not $Quiet) {
                Write-Host ""
                Write-Host "  [重试 $a/$MaxRetries] $($_.Exception.Message)" -ForegroundColor Yellow
            }
            if ($a -lt $MaxRetries) { Start-Sleep -Seconds 2 }
        }
    }
    return $false
}

function Test-UrlLatency {
    param([string]$Url, [int]$TimeoutMs = 5000)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = "GET"
        $req.UserAgent = "HLBot-Installer/1.0"
        $req.Timeout = $TimeoutMs
        $req.ReadWriteTimeout = $TimeoutMs
        $req.AddRange(0, 1023)
        $req.AllowAutoRedirect = $true
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        $resp = $req.GetResponse()
        $s = $resp.GetResponseStream()
        $buf = New-Object byte[] 1024
        $n = 0
        try { $n = $s.Read($buf, 0, 1024) } catch {}
        $sw.Stop()
        $s.Close()
        $resp.Close()
        $ms = [int]$sw.ElapsedMilliseconds
        if ($ms -lt 1) { $ms = 1 }
        $kb = 0
        if ($n -gt 0) { $kb = [math]::Round(($n / 1024.0) / ($ms / 1000.0), 1) }
        return [PSCustomObject]@{ Latency = $ms; SpeedKB = $kb; Bytes = $n }
    } catch { return $null }
}

function Get-LatestList {
    param([string[]]$Urls)
    foreach ($src in $Urls) {
        for ($r = 1; $r -le 3; $r++) {
            $text = Get-UrlText -Url $src -TimeoutSec 15
            if ($text -and $text.Trim() -ne "") {
                $lines = $text -split "`r?`n" | Where-Object { $_.Trim() -ne "" }
                $version = $null
                $u = @()
                foreach ($line in $lines) {
                    $t = $line.Trim()
                    if ($t.StartsWith("#")) {
                        if ($t -match '^#\s*version\s*=\s*(.+)$') { $version = $Matches[1].Trim() }
                        continue
                    }
                    if ($t -match '^https?://') { $u += $t }
                }
                if ($u.Count -gt 0) {
                    return [PSCustomObject]@{ Version = $version; Urls = $u; SourceUrl = $src }
                }
            }
            if ($r -lt 3) { Start-Sleep -Seconds 2 }
        }
    }
    return $null
}

# ============================================================
# 7. 解压（自动探测编码，解决中文乱码）
# ============================================================
$script:ZipEncodingUsed = $null

function Get-ZipCandidateEncodings {
    $list = @()
    try { $list += [System.Text.Encoding]::UTF8 } catch {}
    try { $list += [System.Text.Encoding]::GetEncoding(936) } catch {}
    try { $list += [System.Text.Encoding]::GetEncoding(54936) } catch {}
    if ($list.Count -eq 0) {
        $list += [System.Text.Encoding]::UTF8
    }
    return $list
}

function Test-ZipEntryNames {
    param([string]$ZipPath, [System.Text.Encoding]$Enc, [string[]]$ProbeFiles)
    try {
        $zip = [System.IO.Compression.ZipFile]::Open($ZipPath, [System.IO.Compression.ZipArchiveMode]::Read, $Enc)
        try {
            $entries = @()
            foreach ($entry in $zip.Entries) { $entries += $entry.FullName }
            foreach ($pf in $ProbeFiles) {
                $matched = $false
                foreach ($name in $entries) {
                    if ($name -eq $pf -or $name -like "*/$pf") {
                        $matched = $true
                        break
                    }
                }
                if (-not $matched) { return $false }
            }
            return $true
        } finally {
            $zip.Dispose()
        }
    } catch {
        return $false
    }
}

function Expand-Zip-WithEncoding {
    param([string]$ZipPath, [string]$DestDir, [System.Text.Encoding]$Enc)
    if (-not (Test-Path -LiteralPath $DestDir)) {
        New-Item -ItemType Directory -Path $DestDir -Force | Out-Null
    }
    $zip = [System.IO.Compression.ZipFile]::Open($ZipPath, [System.IO.Compression.ZipArchiveMode]::Read, $Enc)
    try {
        foreach ($entry in $zip.Entries) {
            $entryName = $entry.FullName
            $relative = $entryName -replace '/', '\'
            $targetPath = Join-Path $DestDir $relative
            if ([string]::IsNullOrEmpty($entry.Name)) {
                if (-not (Test-Path -LiteralPath $targetPath)) {
                    New-Item -ItemType Directory -Path $targetPath -Force | Out-Null
                }
            } else {
                $targetDir = Split-Path -Parent $targetPath
                if (-not [string]::IsNullOrEmpty($targetDir) -and -not (Test-Path -LiteralPath $targetDir)) {
                    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
                }
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $targetPath, $true)
            }
        }
    } finally {
        $zip.Dispose()
    }
}

function Expand-Zip {
    param([string]$ZipPath, [string]$DestDir, [string[]]$ProbeFiles)

    $zipApiReady = $false
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $null = [System.IO.Compression.ZipFile]
        $zipApiReady = $true
    } catch {
        $zipApiReady = $false
    }

    if (-not $zipApiReady) {
        Write-Host "[信息] .NET zip 库不可用，回退到 Expand-Archive" -ForegroundColor DarkGray
        $cmd = Get-Command Expand-Archive -ErrorAction SilentlyContinue
        if ($cmd) {
            Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestDir -Force
            $script:ZipEncodingUsed = "Expand-Archive"
            return $true
        }
        Write-Host "[信息] 使用 Shell.Application 解压..." -ForegroundColor DarkGray
        $shell = New-Object -ComObject Shell.Application
        $zipObj = $shell.NameSpace($ZipPath)
        if ($null -eq $zipObj) { throw "无法打开 zip: $ZipPath" }
        $destObj = $shell.NameSpace($DestDir)
        if ($null -eq $destObj) { throw "无法打开目标目录: $DestDir" }
        $topNames = @()
        foreach ($it in $zipObj.Items()) { $topNames += $it.Name }
        $destObj.CopyHere($zipObj.Items(), 16)
        $timeout = 180
        $elapsed = 0
        while ($elapsed -lt $timeout) {
            Start-Sleep -Milliseconds 500
            $elapsed += 0.5
            $ok = $true
            foreach ($n in $topNames) {
                if (-not (Test-Path -LiteralPath (Join-Path $DestDir $n))) { $ok = $false; break }
            }
            if ($ok) { Start-Sleep -Seconds 2; return $true }
        }
        throw "解压超时"
    }

    $candidates = Get-ZipCandidateEncodings
    $chosen = $null

    if ($ProbeFiles -and $ProbeFiles.Count -gt 0) {
        foreach ($enc in $candidates) {
            if (Test-ZipEntryNames -ZipPath $ZipPath -Enc $enc -ProbeFiles $ProbeFiles) {
                $chosen = $enc
                break
            }
        }
    }

    if (-not $chosen) {
        try {
            $zip = [System.IO.Compression.ZipFile]::Open($ZipPath, [System.IO.Compression.ZipArchiveMode]::Read)
            $hasBadChar = $false
            $replacementChar = [char]0xFFFD
            foreach ($entry in $zip.Entries) {
                if ($entry.FullName.IndexOf($replacementChar) -ge 0) {
                    $hasBadChar = $true
                    break
                }
            }
            $zip.Dispose()
            if ($hasBadChar) {
                try { $chosen = [System.Text.Encoding]::GetEncoding(936) } catch {}
            }
        } catch {}
    }

    if (-not $chosen) {
        $chosen = [System.Text.Encoding]::UTF8
    }

    $script:ZipEncodingUsed = $chosen.WebName
    Write-Host "[信息] 检测到 zip 文件名编码: $($chosen.WebName)" -ForegroundColor DarkGray
    Expand-Zip-WithEncoding -ZipPath $ZipPath -DestDir $DestDir -Enc $chosen
    return $true
}

function Backup-Existing {
    param([string]$SourceDir, [string]$BackupRoot)
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $bd = Join-Path $BackupRoot $ts
    New-Item -ItemType Directory -Path $bd -Force | Out-Null
    foreach ($pat in @('*.js','*.bat','*.txt','*.json','*.ps1','*.md')) {
        Get-ChildItem -Path $SourceDir -Filter $pat -File -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try { Copy-Item -LiteralPath $_.FullName -Destination $bd -Force } catch {}
        }
    }
    return $bd
}

# ============================================================
# 8. Log upload（仅在严重错误时调用）
# ============================================================
function Upload-Log {
    param([string]$LocalFilePath, [string]$ErrorMsg = "", [string]$Email = "")
    if (-not (Test-Path -LiteralPath $LocalFilePath)) {
        Write-Host "[上传] 日志文件不存在，跳过上传。"
        return $false
    }
    Stop-TranscriptOnce
    Start-Sleep -Milliseconds 300
    $content = Read-FileText $LocalFilePath
    if ([string]::IsNullOrEmpty($content)) {
        Write-Host "[上传] 无法读取日志文件内容。"
        return $false
    }
    $ip = Get-PublicIP
    $append = "`n===== 上传信息 =====`n用户IP: $ip`n用户邮箱: $Email`n错误信息: $ErrorMsg`n上传时间: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n=====================`n"
    $full = $content + $append
    try { $tmp = [System.IO.Path]::GetTempFileName() } catch {
        Write-Host "[上传] 无法创建临时文件。"
        return $false
    }
    if (-not (Write-FileText -Path $tmp -Content $full)) {
        Write-Host "[上传] 无法写入临时文件。"
        return $false
    }
    try {
        $authUrl = "https://api.backblazeb2.com/b2api/v2/b2_authorize_account"
        $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("$B2_KeyId`:$B2_AppKey"))
        $h = @{ "Authorization" = "Basic $auth" }
        $ar = Invoke-RestMethod -Uri $authUrl -Method Get -Headers $h
        $apiUrl = $ar.apiUrl
        $tok = $ar.authorizationToken
        $listUrl = "$apiUrl/b2api/v2/b2_list_buckets"
        $listBody = @{ accountId = $ar.accountId; bucketName = $B2_BucketName } | ConvertTo-Json
        $lb = Invoke-RestMethod -Uri $listUrl -Method Post -Headers @{ Authorization = $tok } -Body $listBody -ContentType "application/json"
        $bucketId = ($lb.buckets | Where-Object { $_.bucketName -eq $B2_BucketName }).bucketId
        if (-not $bucketId) { throw "未找到桶 '$B2_BucketName'" }
        $upUrl = "$apiUrl/b2api/v2/b2_get_upload_url"
        $upBody = @{ bucketId = $bucketId } | ConvertTo-Json
        $ur = Invoke-RestMethod -Uri $upUrl -Method Post -Headers @{ Authorization = $tok } -Body $upBody -ContentType "application/json"
        $uploadUrl = $ur.uploadUrl
        $uploadTok = $ur.authorizationToken
        $bytes = [System.IO.File]::ReadAllBytes($tmp)
        $sha1Alg = [System.Security.Cryptography.SHA1]::Create()
        $sha1 = [System.BitConverter]::ToString($sha1Alg.ComputeHash($bytes)).Replace("-","").ToLower()
        $remote = "install_log_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
        $uh = @{
            "Authorization"     = $uploadTok
            "X-Bz-File-Name"    = $remote
            "Content-Type"      = "text/plain"
            "X-Bz-Content-Sha1" = $sha1
        }
        $rr = Invoke-RestMethod -Uri $uploadUrl -Method Post -Headers $uh -Body $bytes
        Write-Host "[上传] 上传成功！文件 ID: $($rr.fileId)"
        Write-Host "[上传] 文件名: $remote"
        Write-Host "[上传] 大小: $($rr.contentLength) bytes"
        return $true
    } catch {
        Write-Host "[上传] 上传失败: $_"
        Write-Host "[上传] 请检查网络或密钥是否正确。"
        return $false
    } finally {
        Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
    }
}

# ============================================================
# 9. Global trap（只有这里才会真正上传日志）
# ============================================================
$ErrorActionPreference = "Stop"
trap {
    $msg = "[严重错误] 未捕获异常: $_"
    Add-Content -Path $LogFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" -ErrorAction SilentlyContinue
    Set-FileHidden -Path $LogFile
    Write-Host ""
    Write-Host $msg -ForegroundColor Red
    Write-Host "错误已记录到: $LogFile"
    Write-Host ""
    try { $email = Read-Host "请输入您的邮箱（直接回车跳过；回车后将上传日志）" } catch { $email = "" }
    Upload-Log -LocalFilePath $TranscriptFile -ErrorMsg $msg -Email $email
    Write-Host "按任意键退出..."
    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
    Exit-Safe 1
}

# ============================================================
# 10. i18n
#    NOTE: 不要在双引号字符串内使用中文弯引号 / 英文直引号。
# ============================================================
$M = @{
    "zh" = @{
        Title                = "HLBot 安装程序"
        AskMode              = "请选择操作: (1) 安装 (2) 卸载 (0) 退出"
        Invalid              = "无效输入，请重新选择"
        Exit                 = "程序已退出"
        AskTemp              = "请输入自定义临时目录 (直接回车使用默认): "
        TempDefault          = "使用默认临时目录: "
        TempUnsafe           = "该临时目录不安全（可能是系统目录或盘符根目录），请重新输入。"
        CheckNode            = "正在检测 Node.js..."
        NodeFound            = "Node.js 已安装 (版本: "
        NodeOld              = "Node.js 版本过旧，建议 v$NodeMinMajor 或更高。"
        NodeOldAsk           = "是否仍要继续？(y/n): "
        NodeNotFound         = "未检测到 Node.js，开始下载安装包..."
        DownloadNode         = "正在下载 Node.js 安装包..."
        NodeDownloadComplete = "下载完成，正在启动安装程序..."
        NodeInstallProgress  = "等待 Node.js 安装完成..."
        NodeInstallSuccess   = "Node.js 安装成功！"
        NodeInstallTimeout   = "Node.js 安装超时，请手动安装后重试。"
        AskRestart           = "Node.js 刚安装完成，环境变量可能需要刷新。是否重启安装程序？(y/n): "
        Restarting           = "正在重启安装程序..."
        InstallDeps          = "正在安装项目依赖 (npm install)..."
        DepsSuccess          = "依赖安装完成！"
        DepsFailed           = "依赖安装失败，请检查网络或日志。"
        DepsUpdate           = "检测到已有依赖，是否检查更新？(y/n): "
        DepsUpdating         = "正在更新依赖..."
        DepsUpToDate         = "依赖已是最新版本。"
        DownloadLatest       = "正在获取最新版本信息..."
        DownloadBot          = "正在下载 HLBot 安装包..."
        DownloadComplete     = "下载完成！"
        ExtractBot           = "正在解压安装包..."
        ExtractComplete      = "解压完成！"
        BackupBeforeUpdate   = "正在备份现有文件..."
        VerifyUpdate         = "正在校验更新包完整性..."
        VerifyFailed         = "更新包缺少关键文件，已回退，未覆盖任何文件。"
        InstallComplete      = "安装完成！"
        DeletingTemp         = "正在清理临时文件..."
        OpenLauncher         = "正在启动启动器..."
        UninstallConfirm     = "确认要卸载 HLBot 吗？(y/n): "
        UninstallKeepData    = "是否保留 HLBot_data 用户数据？(y/n，默认 y): "
        Uninstalling         = "正在卸载..."
        UninstallComplete    = "卸载完成！"
        PressAnyKey          = "按任意键继续..."
        SpeedTest            = "正在测速，请稍候..."
        SpeedResult          = "测速结果（延迟 + 速度）："
        SelectLink           = "请选择下载链接 (数字，0 自动，f 强制尝试第一个): "
        AutoSelect           = "已自动选择最优链接"
        UserSelect           = "已选择"
        ForceFirst           = "将强制尝试第一个链接"
        SingleLink           = "只有一个下载链接，直接使用。"
        NoLinks              = "所有链接均不可达，请检查网络。"
        AgreementTitle       = "用户协议"
        AgreementText        = "在继续安装之前，请仔细阅读以下协议：`n1. 本安装程序会收集您的计算机信息（系统版本、PowerShell 版本、安装日志等），仅用于问题排查。`n2. 安装过程中如发生错误，程序会询问您的邮箱并自动上传日志到云端（Backblaze B2）。`n3. 我们还会收集您的公网 IP 地址，用于诊断网络问题。`n4. 日志仅在发生严重错误时才会自动上传。`n5. 如果您不同意以上条款，请选择 3 退出安装。"
        AgreeOption          = "请选择: (1) 查看完整协议 (2) 同意并继续 (3) 不同意并退出"
        AgreedSkip           = "您已同意过本版本协议，跳过。"
        UserAgreed           = "您已同意协议，开始安装..."
        UserDisagreed        = "用户不同意协议，退出安装。"
    }
    "en" = @{
        Title                = "HLBot Installer"
        AskMode              = "Select action: (1) Install (2) Uninstall (0) Exit"
        Invalid              = "Invalid input, please try again"
        Exit                 = "Program exited"
        AskTemp              = "Enter custom temp directory (Enter for default): "
        TempDefault          = "Using default temp directory: "
        TempUnsafe           = "Unsafe temp directory (system folder or drive root). Please retry."
        CheckNode            = "Checking Node.js..."
        NodeFound            = "Node.js found (version: "
        NodeOld              = "Node.js version is too old, v$NodeMinMajor+ recommended."
        NodeOldAsk           = "Continue anyway? (y/n): "
        NodeNotFound         = "Node.js not found, downloading installer..."
        DownloadNode         = "Downloading Node.js installer..."
        NodeDownloadComplete = "Download complete, launching installer..."
        NodeInstallProgress  = "Waiting for Node.js installation..."
        NodeInstallSuccess   = "Node.js installed successfully!"
        NodeInstallTimeout   = "Node.js install timeout. Please install manually."
        AskRestart           = "Node.js was just installed. Restart installer? (y/n): "
        Restarting           = "Restarting installer..."
        InstallDeps          = "Installing dependencies (npm install)..."
        DepsSuccess          = "Dependencies installed!"
        DepsFailed           = "Dependency install failed. Check network or log."
        DepsUpdate           = "Dependencies exist. Check for updates? (y/n): "
        DepsUpdating         = "Updating dependencies..."
        DepsUpToDate         = "Dependencies are up to date."
        DownloadLatest       = "Fetching latest version info..."
        DownloadBot          = "Downloading HLBot package..."
        DownloadComplete     = "Download complete!"
        ExtractBot           = "Extracting package..."
        ExtractComplete      = "Extraction complete!"
        BackupBeforeUpdate   = "Backing up existing files..."
        VerifyUpdate         = "Verifying update package..."
        VerifyFailed         = "Update package missing required files. Rolled back, nothing overwritten."
        InstallComplete      = "Installation complete!"
        DeletingTemp         = "Cleaning up temp files..."
        OpenLauncher         = "Starting launcher..."
        UninstallConfirm     = "Confirm uninstall HLBot? (y/n): "
        UninstallKeepData    = "Keep HLBot_data user data? (y/n, default y): "
        Uninstalling         = "Uninstalling..."
        UninstallComplete    = "Uninstall complete!"
        PressAnyKey          = "Press any key to continue..."
        SpeedTest            = "Testing latency, please wait..."
        SpeedResult          = "Latency results (delay + speed):"
        SelectLink           = "Select download link (number, 0 auto, f force first): "
        AutoSelect           = "Auto selected fastest link"
        UserSelect           = "Selected"
        ForceFirst           = "Will force-try the first link"
        SingleLink           = "Only one download link, using it directly."
        NoLinks              = "All links are unreachable, check your network."
        AgreementTitle       = "User Agreement"
        AgreementText        = "Before proceeding, please read:`n1. This installer collects computer info (OS, PowerShell version, install logs) for troubleshooting.`n2. On errors, we ask for your email and upload logs to Backblaze B2.`n3. We also collect your public IP to diagnose network issues.`n4. Logs are uploaded only when a fatal error occurs.`n5. If you disagree, choose 3 to exit."
        AgreeOption          = "Choose: (1) View full agreement (2) Agree and continue (3) Disagree and exit"
        AgreedSkip           = "You already agreed to this version. Skipping."
        UserAgreed           = "Agreement accepted, starting install..."
        UserDisagreed        = "User declined the agreement, exiting."
    }
}
$Msg = $M[$Lang]

# ============================================================
# 11. Agreement (loop, remembers consent)
# ============================================================
function Show-Agreement {
    if (Test-Path -LiteralPath $AgreementFile) {
        $saved = (Read-FileText $AgreementFile)
        if ($saved -and $saved.Trim() -eq $AgreementVer) {
            Write-Host $Msg.AgreedSkip
            return
        }
    }
    while ($true) {
        Clear-Host
        Write-Host "========================================"
        Write-Host "  $($Msg.Title) v$AppVersion$($script:TitleSuffix)" -ForegroundColor Cyan
        Write-Host "========================================"
        Write-Host ""
        Write-Host $Msg.AgreementText
        Write-Host ""
        $choice = (Read-Host "$($Msg.AgreeOption)").Trim()
        switch ($choice) {
            "1" {
                Clear-Host
                Write-Host "========== $($Msg.AgreementTitle) =========="
                Write-Host $Msg.AgreementText
                Write-Host "============================================="
                Write-Host $Msg.PressAnyKey
                try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch {}
            }
            "2" {
                Write-Host $Msg.UserAgreed
                Write-FileText -Path $AgreementFile -Content $AgreementVer | Out-Null
                Set-FileHidden -Path $AgreementFile
                Add-Content -Path $LogFile -Value "[协议] 用户同意协议，时间 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ErrorAction SilentlyContinue
                Set-FileHidden -Path $LogFile
                return
            }
            "3" {
                Exit-NoUpload -ExitMessage $Msg.UserDisagreed
            }
            default {
                Write-Host $Msg.Invalid
                Start-Sleep -Seconds 1
            }
        }
    }
}

# ============================================================
# 12. Main menu (loop)
# ============================================================
$script:TempDir = Join-Path $env:TEMP "HLBot_Install_$([System.Guid]::NewGuid().ToString().Substring(0,8))"

function Show-MainMenu {
    # 进入主菜单前，统一隐藏一次（兜底）
    Hide-GeneratedFiles -BaseDir $ScriptDir

    Show-Agreement

    if ($script:LocalZipPath) {
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host " [本地包] 检测到拖入的本地安装包，将在安装流程中使用：" -ForegroundColor Cyan
        Write-Host "          $($script:LocalZipPath)" -ForegroundColor Cyan
        Write-Host " [Local] Local package detected, will be used in install flow:" -ForegroundColor Cyan
        Write-Host "         $($script:LocalZipPath)" -ForegroundColor Cyan
        Write-Host "================================================================" -ForegroundColor Cyan
        Write-Host ""
    }

    while ($true) {
        Clear-Host
        Write-Host "========================================"
        Write-Host "  $($Msg.Title) v$AppVersion$($script:TitleSuffix)" -ForegroundColor Cyan
        Write-Host "========================================"
        Write-Log "=== 程序启动 ==="
        $choice = (Read-Host "$($Msg.AskMode)").Trim()
        switch ($choice) {
            "1" { Install-HLBot }
            "2" { Uninstall-HLBot }
            "0" { Exit-NoUpload -ExitMessage $Msg.Exit }
            default { Write-Host $Msg.Invalid; Wait-Key }
        }
    }
}

# ============================================================
# 13. Install flow
# ============================================================
function Install-HLBot {
    Write-Log "=== 开始安装 ==="
    while ($true) {
        $custom = (Read-Host "$($Msg.AskTemp)").Trim()
        if ([string]::IsNullOrEmpty($custom)) { break }
        if (Test-SafeTempDir $custom) { $script:TempDir = $custom; break }
        Write-Host $Msg.TempUnsafe -ForegroundColor Yellow
    }
    Write-Host "$($Msg.TempDefault)$($script:TempDir)"
    Write-Log "临时目录: $($script:TempDir)"
    if (Test-Path -LiteralPath $script:TempDir) {
        Remove-Item -LiteralPath $script:TempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $script:TempDir -Force | Out-Null

    Install-NodeJS
    Download-HLBot
    Install-Dependencies

    Write-Host ""
    Write-Host $Msg.DeletingTemp
    Write-Log "清理临时目录: $($script:TempDir)"
    Remove-Item -LiteralPath $script:TempDir -Recurse -Force -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host $Msg.InstallComplete
    Write-Log "=== 安装完成 ==="
    Write-Host $Msg.OpenLauncher
    try { Start-Process -FilePath "launcher.bat" -WorkingDirectory $ScriptDir } catch {}
    Wait-Key
}

function Install-NodeJS {
    Write-Host ""
    Write-Host $Msg.CheckNode
    Write-Log "检测 Node.js..."
    $ver = $null
    try { $ver = (& node --version 2>$null) } catch { $ver = $null }
    if ($ver) {
        Write-Host "$($Msg.NodeFound)$ver)"
        Write-Log "Node.js 已安装: $ver"
        $major = 0
        if ($ver -match 'v?(\d+)') { $major = [int]$Matches[1] }
        if ($major -gt 0 -and $major -lt $NodeMinMajor) {
            Write-Host $Msg.NodeOld -ForegroundColor Yellow
            $ans = (Read-Host "$($Msg.NodeOldAsk)").Trim()
            if ($ans -notmatch '^[Yy]') { return }
        }
        return
    }
    Write-Host $Msg.NodeNotFound
    Write-Log "Node.js 未安装，开始下载"
    $installer = Join-Path $script:TempDir "node-installer.msi"
    Write-Host $Msg.DownloadNode
    Write-Log "下载 Node.js: $NodeInstallerUrl"
    if (-not (Download-File -Url $NodeInstallerUrl -OutputPath $installer -MaxRetries 3 -TimeoutSec 60)) {
        Write-Log "下载 Node.js 失败"
        Write-Host "[错误] 下载 Node.js 安装包失败，请检查网络。" -ForegroundColor Red
        Wait-Key
        return
    }
    Write-Host ""
    Write-Host $Msg.NodeDownloadComplete
    Write-Log "Node.js 下载完成"

    Write-Host $Msg.NodeInstallProgress
    Write-Log "启动 Node.js 安装程序"
    Start-Process -FilePath $installer -Wait

    $maxWait = 100
    $elapsed = 0
    $ok = $false
    while ($elapsed -lt $maxWait) {
        Start-Sleep -Seconds 2
        $elapsed += 2
        $pct = [math]::Min($elapsed, 100)
        Write-Host -NoNewline "`r$($Msg.NodeInstallProgress) $pct%"
        if ($elapsed % 10 -eq 0) {
            try { $v = (& node --version 2>$null) } catch { $v = $null }
            if ($v) {
                $ok = $true
                Write-Host ""
                Write-Host "$($Msg.NodeInstallSuccess) $v"
                Write-Log "Node.js 安装成功: $v"
                break
            }
        }
    }
    if (-not $ok) {
        try { $v = (& node --version 2>$null) } catch { $v = $null }
        if ($v) {
            Write-Host ""
            Write-Host "$($Msg.NodeInstallSuccess) $v"
            Write-Log "Node.js 安装成功: $v"
        } else {
            Write-Host ""
            Write-Host $Msg.NodeInstallTimeout -ForegroundColor Red
            Write-Log "错误: Node.js 安装超时"
            Remove-Item -LiteralPath $script:TempDir -Recurse -Force -ErrorAction SilentlyContinue
            Wait-Key
            return
        }
    }
    $restart = (Read-Host "$($Msg.AskRestart)").Trim()
    if ($restart -match '^[Yy]') {
        Write-Host $Msg.Restarting
        Write-Log "用户选择重启安装程序"
        Start-Process -FilePath "powershell.exe" -ArgumentList "-File `"$($MyInvocation.MyCommand.Path)`" -Language $Lang" -WorkingDirectory $ScriptDir
        Exit-Safe 0 -NoWait
    }
}

function Install-Dependencies {
    Write-Host ""
    Write-Host $Msg.InstallDeps
    Write-Log "安装依赖..."
    $pkg = Join-Path $ScriptDir "package.json"
    if (-not (Test-Path -LiteralPath $pkg)) {
        Write-Host "未找到 package.json，正在创建默认配置..."
        Write-Log "创建默认 package.json"
        $default = @'
{
  "name": "hlbot",
  "version": "1.0.0",
  "dependencies": {
    "mineflayer": "^4.20.0",
    "minecraft-protocol": "^1.47.0",
    "prismarine-auth": "^2.5.0",
    "yggdrasil": "^1.7.4"
  }
}
'@
        Set-Content -Path $pkg -Value $default -Encoding UTF8
        Set-FileHidden -Path $pkg
    }
    $oldEA = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        if (Test-Path -LiteralPath (Join-Path $ScriptDir "node_modules")) {
            $u = (Read-Host "$($Msg.DepsUpdate)").Trim()
            if ($u -match '^[Yy]') {
                Write-Host $Msg.DepsUpdating
                Write-Log "执行 npm update..."
                & npm update 2>&1 | Tee-Object -FilePath $LogFile -Append
                $code = $LASTEXITCODE
                if ($code -ne 0) {
                    Write-Log "npm update 失败，退出代码: $code"
                    Write-Host $Msg.DepsFailed -ForegroundColor Red
                    Wait-Key
                } else {
                    Write-Host $Msg.DepsUpToDate
                    Write-Log "依赖已更新"
                }
            }
        } else {
            Write-Log "执行 npm install..."
            & npm install 2>&1 | Tee-Object -FilePath $LogFile -Append
            $code = $LASTEXITCODE
            if ($code -ne 0) {
                Write-Log "npm install 失败，退出代码: $code"
                Write-Host $Msg.DepsFailed -ForegroundColor Red
                Wait-Key
            } else {
                Write-Host $Msg.DepsSuccess
                Write-Log "依赖安装成功"
            }
        }
    } finally {
        $ErrorActionPreference = $oldEA
    }
    # npm 可能创建/修改 package-lock.json，重新隐藏
    Set-FileHidden -Path (Join-Path $ScriptDir "package-lock.json")
    Set-FileHidden -Path $LogFile
}

function Download-HLBot {
    $zip = $null

    if ($script:LocalZipPath) {
        if (-not (Test-Path -LiteralPath $script:LocalZipPath)) {
            Write-Host ""
            Write-Host "[警告] 本地安装包不存在: $($script:LocalZipPath)" -ForegroundColor Yellow
            Write-Host "[WARN] Local package not found: $($script:LocalZipPath)" -ForegroundColor Yellow
            Write-Host "将改为在线下载。" -ForegroundColor Yellow
            Write-Host "Falling back to online download." -ForegroundColor Yellow
        } else {
            Write-Host ""
            Write-Host "================================================================" -ForegroundColor Cyan
            Write-Host " 检测到本地安装包 / Local package detected:" -ForegroundColor Cyan
            Write-Host "   $($script:LocalZipPath)" -ForegroundColor Cyan
            Write-Host "================================================================" -ForegroundColor Cyan
            Write-Host ""
            $useLocal = (Read-Host "是否使用此本地安装包进行安装？(y/n) / Use this local package? (y/n)").Trim()
            if ($useLocal -match '^[Yy]') {
                $zip = $script:LocalZipPath
                Write-Log "使用本地安装包: $zip"
                Write-Host "使用本地安装包: $zip" -ForegroundColor Green
                Write-Host "Using local package: $zip" -ForegroundColor Green
            } else {
                Write-Host "改为在线下载。" -ForegroundColor Yellow
                Write-Host "Falling back to online download." -ForegroundColor Yellow
            }
        }
    }

    if (-not $zip) {
        Write-Host ""
        Write-Host $Msg.DownloadLatest
        Write-Log "获取最新版本信息..."

        $info = Get-LatestList -Urls $LatestTxtUrls
        if ($null -eq $info) {
            Write-Log "所有下载源均失败，无法获取下载链接。"
            Write-Host "[错误] 所有下载源均失败，请检查网络。" -ForegroundColor Red
            Wait-Key
            return
        }
        if ($info.Version) { Write-Log "最新版本: $($info.Version)" }
        Write-Log "共 $($info.Urls.Count) 个下载链接"

        $urls = @($info.Urls)
        $chosenUrl = $null

        if ($urls.Count -eq 1) {
            Write-Host $Msg.SingleLink
            $chosenUrl = $urls[0]
        } else {
            Write-Host ""
            Write-Host $Msg.SpeedTest
            $results = @()
            foreach ($u in $urls) {
                $short = if ($u.Length -gt 60) { $u.Substring(0,60) + "..." } else { $u }
                Write-Host -NoNewline "  $short ... "
                $r = Test-UrlLatency -Url $u -TimeoutMs 5000
                if ($null -ne $r) {
                    Write-Host "$($r.Latency)ms  $($r.SpeedKB) KB/s"
                    $results += [PSCustomObject]@{ Url = $u; Latency = $r.Latency; SpeedKB = $r.SpeedKB; Status = "可达" }
                } else {
                    Write-Host "不可达"
                    $results += [PSCustomObject]@{ Url = $u; Latency = [int]::MaxValue; SpeedKB = 0; Status = "不可达" }
                }
            }
            $sorted = $results | Sort-Object Latency
            Write-Host ""
            Write-Host $Msg.SpeedResult
            for ($i = 0; $i -lt $sorted.Count; $i++) {
                $tag = if ($sorted[$i].Status -eq "不可达") { " (超时)" } else { "" }
                Write-Host "  $($i+1). $($sorted[$i].Url)"
                Write-Host "      $($sorted[$i].Latency)ms   $($sorted[$i].SpeedKB) KB/s$tag"
            }
            Write-Host "  0. $($Msg.AutoSelect)"
            Write-Host "  f. $($Msg.ForceFirst)"
            $choice = (Read-Host "$($Msg.SelectLink)").Trim()
            if ($choice -eq "f" -or $choice -eq "F") {
                $chosenUrl = $urls[0]
                Write-Host $Msg.ForceFirst
            } elseif ([string]::IsNullOrEmpty($choice) -or $choice -eq "0") {
                $avail = $sorted | Where-Object { $_.Status -eq "可达" }
                $sel = if ($avail) { $avail[0] } else { $sorted[0] }
                $chosenUrl = $sel.Url
                Write-Host "$($Msg.AutoSelect): $chosenUrl ($($sel.Latency)ms)"
            } else {
                $idx = 0
                [void][int]::TryParse($choice, [ref]$idx)
                $idx = $idx - 1
                if ($idx -ge 0 -and $idx -lt $sorted.Count) {
                    $chosenUrl = $sorted[$idx].Url
                    Write-Host "$($Msg.UserSelect): $chosenUrl ($($sorted[$idx].Latency)ms)"
                } else {
                    Write-Host "$($Msg.Invalid) $($Msg.AutoSelect)"
                    $avail = $sorted | Where-Object { $_.Status -eq "可达" }
                    $sel = if ($avail) { $avail[0] } else { $sorted[0] }
                    $chosenUrl = $sel.Url
                }
            }
        }

        Write-Host ""
        Write-Host $Msg.DownloadBot
        Write-Log "下载 HLBot: $chosenUrl"
        $zip = Join-Path $script:TempDir "HLBot.zip"
        if (-not (Download-File -Url $chosenUrl -OutputPath $zip -MaxRetries 3 -TimeoutSec 60)) {
            Write-Log "下载 HLBot 失败"
            Write-Host "[错误] 下载安装包失败。" -ForegroundColor Red
            Wait-Key
            return
        }
        Write-Host ""
        Write-Host $Msg.DownloadComplete
        Write-Log "下载完成"
    }

    Write-Host $Msg.ExtractBot
    $extractDir = Join-Path $script:TempDir "extracted"
    New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
    try {
        Expand-Zip -ZipPath $zip -DestDir $extractDir -ProbeFiles $RequiredUpdateFiles | Out-Null
        Write-Host $Msg.ExtractComplete
        Write-Log "解压完成 (编码: $($script:ZipEncodingUsed))"
    } catch {
        Write-Log "解压失败: $_"
        Write-Host "[错误] 解压失败: $_" -ForegroundColor Red
        Wait-Key
        return
    }

    $top = @(Get-ChildItem -LiteralPath $extractDir -Force)
    $srcDir = $extractDir
    if ($top.Count -eq 1 -and $top[0].PSIsContainer) { $srcDir = $top[0].FullName }

    Write-Host $Msg.VerifyUpdate
    $missing = @()
    foreach ($f in $RequiredUpdateFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $srcDir $f))) { $missing += $f }
    }

    $forceInstall = $false
    if ($missing.Count -gt 0) {
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host " [错误] 更新包缺少关键文件 / Missing required files:" -ForegroundColor Red
        foreach ($m in $missing) {
            Write-Host "         - $m" -ForegroundColor Red
        }
        Write-Host "================================================================" -ForegroundColor Red
        Write-Host ""
        Write-Host " 可能原因 / Possible reasons:" -ForegroundColor Yellow
        Write-Host "   1. 压缩包不完整或损坏" -ForegroundColor Yellow
        Write-Host "   2. 文件被误删" -ForegroundColor Yellow
        Write-Host "   3. 使用了旧版本 / 第三方修改的压缩包" -ForegroundColor Yellow
        Write-Host ""
        Write-Host " 如果你确定这是有意为之（例如自行修改了安装包），" -ForegroundColor Yellow
        Write-Host " 可以选择开发者模式强制安装，跳过完整性校验。" -ForegroundColor Yellow
        Write-Host " If you know what you're doing, enable Developer Mode to force install." -ForegroundColor Yellow
        Write-Host ""

        $forceChoice = (Read-Host " 是否使用开发者模式强制安装？(y/n) / Force install? (y/n)").Trim()
        if ($forceChoice -match '^[Yy]') {
            Write-Host ""
            Write-Host "================================================================" -ForegroundColor Yellow
            Write-Host " [警告] 开发者模式已启用 / Developer Mode enabled" -ForegroundColor Yellow
            Write-Host "        - 将跳过关键文件完整性校验" -ForegroundColor Yellow
            Write-Host "        - 缺失的文件不会被复制" -ForegroundColor Yellow
            Write-Host "        - 可能导致程序无法正常运行" -ForegroundColor Yellow
            Write-Host "        - 请确认你知道自己在做什么" -ForegroundColor Yellow
            Write-Host "================================================================" -ForegroundColor Yellow
            Write-Host ""
            Write-Log "[开发者模式] 用户选择强制安装，缺失文件: $($missing -join ', ')"
            $forceInstall = $true
            Start-Sleep -Seconds 2
        } else {
            Write-Host ""
            Write-Host " 已取消安装 / Installation cancelled." -ForegroundColor Yellow
            Write-Log "用户取消安装（缺少关键文件）"
            Wait-Key
            return
        }
    }

    Write-Host $Msg.BackupBeforeUpdate
    $backupDir = Join-Path $ScriptDir "backup"
    if (-not (Test-Path -LiteralPath $backupDir)) {
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
    }
    try {
        $bpath = Backup-Existing -SourceDir $ScriptDir -BackupRoot $backupDir
        Write-Log "已备份到: $bpath"
    } catch {
        Write-Log "备份失败（继续）: $_"
    }

    $entries = Get-ChildItem -LiteralPath $srcDir -Force
    $failCnt = 0
    foreach ($e in $entries) {
        if ($ProtectedPaths -contains $e.Name) { continue }
        $dst = Join-Path $ScriptDir $e.Name
        try {
            if ($e.PSIsContainer) {
                if (Test-Path -LiteralPath $dst) {
                    Remove-Item -LiteralPath $dst -Recurse -Force -ErrorAction SilentlyContinue
                }
                Copy-Item -LiteralPath $e.FullName -Destination $dst -Recurse -Force
            } else {
                Copy-Item -LiteralPath $e.FullName -Destination $dst -Force
            }
            Write-Host "  OK $($e.Name)" -ForegroundColor Green
        } catch {
            Write-Host "  FAIL $($e.Name): $($_.Exception.Message)" -ForegroundColor Yellow
            $failCnt++
        }
    }
    if ($failCnt -gt 0) {
        Write-Log "有 $failCnt 个文件复制失败"
        Write-Host "有 $failCnt 个文件未能覆盖，请手动处理。" -ForegroundColor Yellow
    }

    # 复制完成后重新隐藏（新复制过来的文件属性会重置）
    Hide-GeneratedFiles -BaseDir $ScriptDir

    if ($forceInstall) {
        Write-Host ""
        Write-Host "================================================================" -ForegroundColor Yellow
        Write-Host " [提示] 本次为开发者模式强制安装。" -ForegroundColor Yellow
        Write-Host "        缺失的文件未被复制，程序可能无法正常运行。" -ForegroundColor Yellow
        Write-Host "        建议尽快获取完整安装包并重新安装。" -ForegroundColor Yellow
        Write-Host " [INFO] Force install was used. Some files may be missing." -ForegroundColor Yellow
        Write-Host "        Please obtain a complete package and reinstall." -ForegroundColor Yellow
        Write-Host "================================================================" -ForegroundColor Yellow
        Write-Host ""
        Write-Log "[开发者模式] 强制安装完成，缺失文件: $($missing -join ', ')"
    }
}

# ============================================================
# 14. Uninstall
# ============================================================
function Uninstall-HLBot {
    $c = (Read-Host "$($Msg.UninstallConfirm)").Trim()
    if ($c -notmatch '^[Yy]') { return }
    Write-Host $Msg.Uninstalling
    Write-Log "=== 开始卸载 ==="
    $keep = (Read-Host "$($Msg.UninstallKeepData)").Trim()
    $keepData = -not ($keep -match '^[Nn]')

    $items = @(
        "launcher.js","launcher.bat","auth.js","官方默认脚本.js",
        "help.txt","package.json","package-lock.json","node_modules",
        "install.log","install_transcript.log",".hlbot_agreement",".hlbot_lang",
        "error.log"
    )
    foreach ($f in $items) {
        $t = Join-Path $ScriptDir $f
        if (Test-Path -LiteralPath $t) {
            try {
                # 先去掉隐藏属性再删
                try { (Get-Item -LiteralPath $t -Force).Attributes = 'Normal' } catch {}
                Remove-Item -LiteralPath $t -Recurse -Force -ErrorAction SilentlyContinue
                Write-Log "已删除: $f"
            } catch {
                Write-Log "删除失败: $f ($_)"
            }
        }
    }
    if (-not $keepData) {
        $d = Join-Path $ScriptDir "HLBot_data"
        if (Test-Path -LiteralPath $d) {
            Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "已删除: HLBot_data"
        }
    }
    Write-Host $Msg.UninstallComplete
    Write-Log "=== 卸载完成 ==="
    Wait-Key
}

# ============================================================
# 15. Entry
# ============================================================
Show-MainMenu