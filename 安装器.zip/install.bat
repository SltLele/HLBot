@echo off
cd /d "%~dp0"
set "HLBOT_NOEXIT=1"

set "PS_EXE=powershell"

if exist "C:\Program Files\PowerShell\7\pwsh.exe" (
    "C:\Program Files\PowerShell\7\pwsh.exe" -NoLogo -NoProfile -Command "exit 0" >nul 2>&1
    if not errorlevel 1 set "PS_EXE=C:\Program Files\PowerShell\7\pwsh.exe"
)

if "%PS_EXE%"=="powershell" if exist "%LOCALAPPDATA%\Microsoft\WindowsApps\pwsh.exe" (
    "%LOCALAPPDATA%\Microsoft\WindowsApps\pwsh.exe" -NoLogo -NoProfile -Command "exit 0" >nul 2>&1
    if not errorlevel 1 set "PS_EXE=%LOCALAPPDATA%\Microsoft\WindowsApps\pwsh.exe"
)

"%PS_EXE%" -NoLogo -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*

echo.
pause